public class MainLevenshtein {
    public static void main(String[] args) {
        System.out.println(Levenshtein2.similitude("dias buenos", "buenos dias"));

        System.out.println(Levenshtein2.implementation2("cacona", "caquita"));


    }
}
