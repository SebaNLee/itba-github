import java.time.Instant;

public class MainTimer {
    public static void main(String[] args) {
        Timer timer = new Timer();
        System.out.println(timer);
    }
}
