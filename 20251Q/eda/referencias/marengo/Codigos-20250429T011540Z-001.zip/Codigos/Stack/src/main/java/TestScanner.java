import java.util.Scanner;

public class TestScanner {
    public static void main(String[] args) {
        Double rta = new Evaluator().evaluate();
        System.out.println(rta);
    }
}
