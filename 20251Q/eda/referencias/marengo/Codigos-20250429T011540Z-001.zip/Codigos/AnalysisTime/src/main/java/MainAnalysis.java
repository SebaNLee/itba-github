public class MainAnalysis {
    public static void main(String[] args) {
        Timer timer = new Timer(100);
        timer.stop(400);
        System.out.println(timer);
    }
}
