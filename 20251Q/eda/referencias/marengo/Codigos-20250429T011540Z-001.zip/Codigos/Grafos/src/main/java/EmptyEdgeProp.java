public class EmptyEdgeProp {

	@Override
	public String toString() {
		return "[]";
	}
}